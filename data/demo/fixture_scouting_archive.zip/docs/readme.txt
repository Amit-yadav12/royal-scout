Synthetic demonstration archive for Royal Scout.
